import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SocialpagePage } from './socialpage';

@NgModule({
  declarations: [
    SocialpagePage,
  ],
  imports: [
    IonicPageModule.forChild(SocialpagePage),
  ],
})
export class SocialpagePageModule {}
